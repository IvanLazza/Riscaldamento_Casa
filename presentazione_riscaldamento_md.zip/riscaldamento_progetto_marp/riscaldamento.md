---
marp: true
theme: default
style: |
  section {
    background-color: #eeeae5;
    color: white;
  }
  section.center {
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
  }
  .big { font-size: 78px; }
  section, h1, h2, h3, h4, h5, h6, p, li {
    color: black;
  }
---
<style>
section.large-text {
  font-size: 20px;
  line-height: 1.4;
}
</style>

<!-- _class: center -->

![bg right:50%](riscaldamento_images/page1_img1.png)

<span class="big">**IL RISCALDAMENTO**</span>
### Lazzarini · Maranta · Pareccini · Rossi · Salmoiraghi

<!-- _backgroundSize: 40% -->(riscaldamento_images/page1_img1.png)

---
<!-- _class: large-text -->

# Introduzione

La nostra classe si è unita per realizzare un grande progetto: la gestione di una casa.  
Per portare a termine questo compito ci siamo suddivisi le varie funzionalità, al fine di lavorarci e realizzare dei programmi in Java che descrivano l’esatto funzionamento dei suoi vari dispositivi, nel nostro caso di riscaldamento.  

Abbiamo scelto questa branca perchè c’è molta attrezzatura dedicata a questa funzione e volevamo analizzarne il contenuto in modo approfondito, attraverso varie ricerche svolte insieme.

![bg right:40%](riscaldamento_images/page2_img1.png)

---
<!-- _class: large-text -->
# Le ricerche

Abbiamo cominciato ricercando sul web ogni tipo di riscaldamento e, una volta trovato tutto, ci siamo segnati su un file Excel il consumo giornaliero di ognuno in kWh, per poi andare a costruire il calcolo della spesa totale.  

Successivamente ci siamo occupati dell’inserimento di tutti i dispositivi nel nostro programma, realizzando una classe per ognuno.


![width:10%](riscaldamento_images/tabella.png) 

![bg right:35%](riscaldamento_images\ricerca2.jpg)


---
<style>
section.large-text {
  font-size: 20px;
  line-height: 1.4;
}
</style>

<!-- _class: center -->
<span class="big">**Categorie di Dispositivi**</span>
<br>
<br>

| | | |
|---|---|---|
|**Dispositivi elettrici**| **Dispositivi idronici** | **Pannelli solari** |

 
---

# Dispositivi elettrici

<div style="display:flex; gap:50px; align-items:center;">

<div style="flex:1; font-size:26px; line-height:1.4;">

I dispositivi elettrici, i più diffusi tra i tre, funzionano tramite l’energia elettrica e garantiscono un riscaldamento rapido e immediato.

Sono facili da installare e adatti a piccoli spazi o utilizzi occasionali, ma consumano più energia rispetto ai sistemi idronici.

![bg right:40%](riscaldamento_images\riscaldamentoelettrico.png)
---

---

# Dispositivi idronici

I dispositivi idronici utilizzano l’acqua calda o fredda per riscaldare o raffrescare gli ambienti.  

Offrono un comfort uniforme e costante, ma richiedono un impianto idraulico dedicato.  

Sono ideali per case e uffici, grazie alla loro efficienza e alla distribuzione omogenea del calore.

![bg right:40%](riscaldamento_images\gg.jpg)

---

# Pannelli solari

I pannelli solari sfruttano l’energia del sole per produrre elettricità o acqua calda.  

Rappresentano una soluzione sostenibile e conveniente nel lungo periodo, riducendo i costi energetici e l’impatto ambientale.  

Ideali in abitazioni con buona esposizione solare.

![bg right:40%](riscaldamento_images\pannellisolari.png)

---

# Fasi della programmazione
<br>
<br>
<br>


## Creazione classi     Modifica clock            Jaylib  
## ●───────────────────●───────────────●

---


# Cosa abbiamo imparato

| | | |
|---|---|---|
| ![](riscaldamento_images\page6_img1.png) | ![](riscaldamento_images\page6_img2.png) | ![](riscaldamento_images\page6_img3.png) |
| **Utilizzo consapevole dei dispositivi** | **Conoscenza dell’impatto energetico** | **Complessità nel riscaldare una casa** |

---

# Grazie

<div class="columns">

<div>

<div style="background:#6b6464; color:white; padding:40px; text-align:left;">
Se non sceglierete il nostro programma il vostro sistema di riscaldamento sarà composto da elementi simili al seguente

<br>

<img src="riscaldamento_images/allert.png" width="500">

</div>

</div>

<div>

![bg right:55%](riscaldamento_images\page7_img1.png)

</div>

</div>
